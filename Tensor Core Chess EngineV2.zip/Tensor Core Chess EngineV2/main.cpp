#include <algorithm>
#include <cctype>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "Board.h"
#include "HC_Eval.h"
#include "Min_Max.h"

using namespace std;

static const string START_FEN =
    "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

string MoveToUCI(const Move& move)
{
    if (move.fromX < 0 || move.toX < 0)
        return "0000";

    string result;
    result += char('a' + move.fromY);
    result += char('1' + move.fromX);
    result += char('a' + move.toY);
    result += char('1' + move.toX);
    return result;
}

bool ParseUCIMove(Board& board, const string& text, Move& result)
{
    if (text.size() < 4)
        return false;

    int fromY = text[0] - 'a';
    int fromX = text[1] - '1';
    int toY   = text[2] - 'a';
    int toX   = text[3] - '1';

    if (fromX < 0 || fromX >= 8 || fromY < 0 || fromY >= 8 ||
        toX < 0 || toX >= 8 || toY < 0 || toY >= 8)
        return false;

    vector<Move> moves = board.generateMoves(fromX, fromY);
    for (const Move& move : moves)
    {
        if (move.fromX == fromX && move.fromY == fromY &&
            move.toX == toX && move.toY == toY)
        {
            result = move;
            return true;
        }
    }

    return false;
}

void ApplyUCIMove(Board& board, const string& text)
{
    Move move;
    if (!ParseUCIMove(board, text, move))
        return;

    board.makeMove(move);
    board.sideToMove = (board.sideToMove == WHITE) ? BLACK : WHITE;
}

void SetStartPosition(Board& board)
{
    board.Load_FEN(START_FEN);
}

void HandlePosition(Board& board, const string& command)
{
    stringstream ss(command);
    string token;
    ss >> token; // position
    ss >> token;

    if (token == "startpos")
    {
        SetStartPosition(board);
    }
    else if (token == "fen")
    {
        string fen;
        for (int i = 0; i < 6 && ss >> token; ++i)
        {
            if (i) fen += ' ';
            fen += token;
        }
        board.Load_FEN(fen);
    }
    else
    {
        return;
    }

    if (ss >> token && token == "moves")
    {
        while (ss >> token)
            ApplyUCIMove(board, token);
    }
}

void HandleGo(Board& board, Min_Max& engine, const string& command)
{
    stringstream ss(command);
    string token;
    int depth = 30;

    ss >> token; // go
    while (ss >> token)
    {
        if (token == "depth")
            ss >> depth;
        else if (token == "movetime")
        {
            // Time management is not implemented yet; use a bounded depth.
            int ignored;
            ss >> ignored;
            depth = max(1, min(depth, 6));
        }
    }

    bool maximizing = (board.sideToMove == WHITE);
    Move best = engine.FindBestMove(board, depth, maximizing);
    cout << "bestmove " << MoveToUCI(best) << endl;
}

int main()
{
    Board board;
    Min_Max engine;
    SetStartPosition(board);

    string command;
    while (getline(cin, command))
    {
        if (command == "uci")
        {
            cout << "id name Tensor Core Chess Engine\n";
            cout << "id author Szymon Glura\n";
            cout << "option name Threads type spin default 1 min 1 max 128\n";
            cout << "uciok\n";
        }
        else if (command == "isready")
        {
            cout << "readyok" << endl;
        }
        else if (command == "ucinewgame")
        {
            SetStartPosition(board);
        }
        else if (command.rfind("setoption", 0) == 0)
        {
            stringstream ss(command);
            string word, name, value;
            ss >> word; // setoption
            ss >> word; // name
            ss >> name;
            ss >> word; // value
            ss >> value;

            if (name == "Threads" && !value.empty())
            {
                try { engine.SetThreads(stoi(value)); }
                catch (...) { }
            }
        }
        else if (command.rfind("position", 0) == 0)
        {
            HandlePosition(board, command);
        }
        else if (command.rfind("go", 0) == 0)
        {
            HandleGo(board, engine, command);
        }
        else if (command == "stop")
        {
            // Search is synchronous; stop will be supported with cancellable search later.
        }
        else if (command == "quit")
        {
            break;
        }
    }

    return 0;
}
