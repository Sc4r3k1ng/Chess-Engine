#ifndef MIN_MAX_H
#define MIN_MAX_H

#include "Board.h"
#include "HC_Eval.h"

class Min_Max
{
public:
    Min_Max();
    virtual ~Min_Max();

    int Search(Board& board, int depth, bool maximizingPlayer);
    int AlphaBeta(Board& board, int depth, int alpha, int beta, bool maximizingPlayer);
    int Quiescence(Board& board, int alpha, int beta);

    Move FindBestMove(Board& board, int depth, bool maximizingPlayer);

    void SetThreads(int count);
    int GetThreads() const;

private:
    int SearchRootMove(const Board& position, const Move& move, int depth, bool maximizingPlayer);

    HC_Eval evaluator;
    int threads;
};

#endif
