#ifndef TWPAO_EVAL_H
#define TWPAO_EVAL_H
#include <vector>
class TWPAO_Eval
{
public:
    TWPAO_Eval();
    virtual ~TWPAO_Eval();
    void RecordPosition(const std::vector<int>&,int);
    void Train();
    bool SaveWeights(const char*);
    bool LoadWeights(const char*);
private:
    std::vector<int> samples;
};
#endif
