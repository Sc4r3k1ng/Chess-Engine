#ifndef HC_EVAL_H
#define HC_EVAL_H

#include "Board.h"

class HC_Eval
{
public:
    HC_Eval();
    ~HC_Eval();

    int Evaluate(Board& board);

private:
    int EvaluateMaterial(Board& board);
    int EvaluatePosition(Board& board);
    int EvaluateMobility(Board& board);
    int EvaluateKingSafety(Board& board);
    int EvaluatePassedPawns(Board& board);
    int EvaluateDoubledPawns(Board& board);
    int EvaluateIsolatedPawns(Board& board);
    int EvaluateBishopPair(Board& board);
    int EvaluateRookActivity(Board& board);
};

#endif
