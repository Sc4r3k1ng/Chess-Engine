#ifndef DEBUG_H
#define DEBUG_H

using namespace std;

class Debug
{
    public:
        Debug();
        virtual ~Debug();

    protected:

    private:
};

#endif // DEBUG_H
