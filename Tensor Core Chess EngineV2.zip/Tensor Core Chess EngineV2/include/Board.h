#ifndef BOARD_H
#define BOARD_H

#include <string>
#include <utility>
#include <vector>

using namespace std;

const char Column[8] = {'A','B','C','D','E','F','G','H'};
const char Row[8]    = {'1','2','3','4','5','6','7','8'};

enum PieceType
{
    EMPTY,
    KING,
    QUEEN,
    ROOK,
    BISHOP,
    KNIGHT,
    PAWN
};

enum Color
{
    NONE,
    WHITE,
    BLACK
};

struct Piece
{
    PieceType type;
    Color color;
};

struct Move
{
    int fromX;
    int fromY;
    int toX;
    int toY;
};

class Board
{
public:
    Board();
    ~Board();

    Piece board[8][8];
    Color sideToMove = WHITE;

    void Show_Board();
    void Load_FEN(const string& fen);

    // Returns legal moves for the piece at x,y.
    vector<Move> generateMoves(int x, int y);

    Piece makeMove(const Move& move);
    void undoMove(const Move& move, Piece captured);

    bool inCheck(Color side);
    bool hasLegalMoves(Color side);

private:
    bool isInBounds(int x, int y);

    // Pseudo-legal generators.
    vector<Move> generateKingMoves(int x, int y);
    vector<Move> generateQueenMoves(int x, int y);
    vector<Move> generateRookMoves(int x, int y);
    vector<Move> generateBishopMoves(int x, int y);
    vector<Move> generateKnightMoves(int x, int y);
    vector<Move> generatePawnMoves(int x, int y);

    pair<int,int> findKing(Color color);
    bool isSquareAttacked(int x, int y, Color attacker);
};

#endif
