#include "HC_Eval.h"
#include "Board.h"
#include <algorithm>

HC_Eval::HC_Eval()
{

}
HC_Eval::~HC_Eval()
{


}
const int PawnTable[8][8] =
{
    {  0,  0,  0,  0,  0,  0,  0,  0},
    { 50, 50, 50, 50, 50, 50, 50, 50},
    { 10, 10, 20, 30, 30, 20, 10, 10},
    {  5,  5, 10, 25, 25, 10,  5,  5},
    {  0,  0,  0, 20, 20,  0,  0,  0},
    {  5, -5,-10,  0,  0,-10, -5,  5},
    {  5, 10, 10,-20,-20, 10, 10,  5},
    {  0,  0,  0,  0,  0,  0,  0,  0}
};

const int KnightTable[8][8] =
{
    {-50,-40,-30,-30,-30,-30,-40,-50},
    {-40,-20,  0,  5,  5,  0,-20,-40},
    {-30,  5, 10, 15, 15, 10,  5,-30},
    {-30,  0, 15, 20, 20, 15,  0,-30},
    {-30,  5, 15, 20, 20, 15,  5,-30},
    {-30,  0, 10, 15, 15, 10,  0,-30},
    {-40,-20,  0,  0,  0,  0,-20,-40},
    {-50,-40,-30,-30,-30,-30,-40,-50}
};

const int BishopTable[8][8] =
{
    {-20,-10,-10,-10,-10,-10,-10,-20},
    {-10,  5,  0,  0,  0,  0,  5,-10},
    {-10, 10, 10, 10, 10, 10, 10,-10},
    {-10,  0, 10, 10, 10, 10,  0,-10},
    {-10,  5,  5, 10, 10,  5,  5,-10},
    {-10,  0,  5, 10, 10,  5,  0,-10},
    {-10,  0,  0,  0,  0,  0,  0,-10},
    {-20,-10,-10,-10,-10,-10,-10,-20}
};

const int RookTable[8][8] =
{
    {  0,  0,  5, 10, 10,  5,  0,  0},
    { -5,  0,  0,  0,  0,  0,  0, -5},
    { -5,  0,  0,  0,  0,  0,  0, -5},
    { -5,  0,  0,  0,  0,  0,  0, -5},
    { -5,  0,  0,  0,  0,  0,  0, -5},
    { -5,  0,  0,  0,  0,  0,  0, -5},
    {  5, 10, 10, 10, 10, 10, 10,  5},
    {  0,  0,  0,  0,  0,  0,  0,  0}
};

const int QueenTable[8][8] =
{
    {-20,-10,-10, -5, -5,-10,-10,-20},
    {-10,  0,  0,  0,  0,  5,  0,-10},
    {-10,  0,  5,  5,  5,  5,  5,-10},
    { -5,  0,  5,  5,  5,  5,  0, -5},
    {  0,  0,  5,  5,  5,  5,  0, -5},
    {-10,  5,  5,  5,  5,  5,  0,-10},
    {-10,  0,  5,  0,  0,  0,  0,-10},
    {-20,-10,-10, -5, -5,-10,-10,-20}
};

const int KingTable[8][8] =
{
    {-30,-40,-40,-50,-50,-40,-40,-30},
    {-30,-40,-40,-50,-50,-40,-40,-30},
    {-30,-40,-40,-50,-50,-40,-40,-30},
    {-30,-40,-40,-50,-50,-40,-40,-30},
    {-20,-30,-30,-40,-40,-30,-30,-20},
    {-10,-20,-20,-20,-20,-20,-20,-10},
    { 20, 20,  0,  0,  0,  0, 20, 20},
    { 20, 30, 10,  0,  0, 10, 30, 20}
};

const int KingEndgameTable[8][8] =
{
    {-50,-40,-30,-20,-20,-30,-40,-50},
    {-30,-20,-10,  0,  0,-10,-20,-30},
    {-30,-10, 20, 30, 30, 20,-10,-30},
    {-30,-10, 30, 40, 40, 30,-10,-30},
    {-30,-10, 30, 40, 40, 30,-10,-30},
    {-30,-10, 20, 30, 30, 20,-10,-30},
    {-30,-30,  0,  0,  0,  0,-30,-30},
    {-50,-30,-30,-30,-30,-30,-30,-50}
};
const int BishopPairBonus      = 35;
const int DoubledPawnPenalty   = -15;
const int IsolatedPawnPenalty  = -20;
const int PassedPawnBonus      = 30;
const int RookOpenFileBonus    = 20;
const int RookSeventhRankBonus = 25;
const int KnightOutpostBonus   = 20;

int HC_Eval::EvaluateBishopPair(Board& board)
{
    int whiteBishops = 0;
    int blackBishops = 0;

    for(int x = 0; x < 8; x++)
    {
        for(int y = 0; y < 8; y++)
        {
            const Piece& p = board.board[x][y];

            if(p.type != BISHOP)
                continue;

            if(p.color == WHITE)
                whiteBishops++;
            else
                blackBishops++;
        }
    }

    int score = 0;

    if(whiteBishops >= 2)
        score += BishopPairBonus;

    if(blackBishops >= 2)
        score -= BishopPairBonus;

    return score;
}

int HC_Eval::EvaluateDoubledPawns(Board& board)
{
    int score = 0;

    for(int file = 0; file < 8; file++)
    {
        int white = 0;
        int black = 0;

        for(int rank = 0; rank < 8; rank++)
        {
            const Piece& p = board.board[rank][file];

            if(p.type != PAWN)
                continue;

            if(p.color == WHITE)
                white++;
            else
                black++;
        }

        if(white > 1)
            score += (white - 1) * DoubledPawnPenalty;

        if(black > 1)
            score -= (black - 1) * DoubledPawnPenalty;
    }

    return score;
}

int HC_Eval::EvaluateIsolatedPawns(Board& board)
{
    int score = 0;

    for(int x = 0; x < 8; x++)
    {
        for(int y = 0; y < 8; y++)
        {
            const Piece& p = board.board[x][y];

            if(p.type != PAWN)
                continue;

            bool neighbour = false;

            for(int file = y - 1; file <= y + 1; file += 2)
            {
                if(file < 0 || file >= 8)
                    continue;

                for(int rank = 0; rank < 8; rank++)
                {
                    const Piece& q = board.board[rank][file];

                    if(q.type == PAWN && q.color == p.color)
                    {
                        neighbour = true;
                        break;
                    }
                }
            }

            if(!neighbour)
            {
                if(p.color == WHITE)
                    score += IsolatedPawnPenalty;
                else
                    score -= IsolatedPawnPenalty;
            }
        }
    }

    return score;
}

int HC_Eval::EvaluatePassedPawns(Board& board)
{
    int score = 0;

    for(int x = 0; x < 8; x++)
    {
        for(int y = 0; y < 8; y++)
        {
            const Piece& p = board.board[x][y];

            if(p.type != PAWN)
                continue;

            bool passed = true;

            if(p.color == WHITE)
            {
                for(int rank = x - 1; rank >= 0 && passed; rank--)
                {
                    for(int file = max(0, y - 1); file <= min(7, y + 1); file++)
                    {
                        const Piece& q = board.board[rank][file];

                        if(q.type == PAWN && q.color == BLACK)
                        {
                            passed = false;
                            break;
                        }
                    }
                }

                if(passed)
                    score += PassedPawnBonus;
            }
            else
            {
                for(int rank = x + 1; rank < 8 && passed; rank++)
                {
                    for(int file = max(0, y - 1); file <= min(7, y + 1); file++)
                    {
                        const Piece& q = board.board[rank][file];

                        if(q.type == PAWN && q.color == WHITE)
                        {
                            passed = false;
                            break;
                        }
                    }
                }

                if(passed)
                    score -= PassedPawnBonus;
            }
        }
    }

    return score;
}

int HC_Eval::EvaluateRookActivity(Board& board)
{
    int score = 0;

    for(int x = 0; x < 8; x++)
    {
        for(int y = 0; y < 8; y++)
        {
            const Piece& p = board.board[x][y];

            if(p.type != ROOK)
                continue;

            bool pawnFound = false;

            for(int rank = 0; rank < 8; rank++)
            {
                if(board.board[rank][y].type == PAWN)
                {
                    pawnFound = true;
                    break;
                }
            }

            if(!pawnFound)
            {
                if(p.color == WHITE)
                    score += RookOpenFileBonus;
                else
                    score -= RookOpenFileBonus;
            }

            if(p.color == WHITE && x == 1)
                score += RookSeventhRankBonus;

            if(p.color == BLACK && x == 6)
                score -= RookSeventhRankBonus;
        }
    }

    return score;
}

int HC_Eval::EvaluateMaterial(Board& board)
{
    int score = 0;

    for(int x = 0; x < 8; x++)
    {
        for(int y = 0; y < 8; y++)
        {
            const Piece& p = board.board[x][y];

            switch(p.type)
            {
            case PAWN:
                score += (p.color == WHITE) ? 100 : -100;
                break;

            case KNIGHT:
                score += (p.color == WHITE) ? 320 : -320;
                break;

            case BISHOP:
                score += (p.color == WHITE) ? 330 : -330;
                break;

            case ROOK:
                score += (p.color == WHITE) ? 500 : -500;
                break;

            case QUEEN:
                score += (p.color == WHITE) ? 900 : -900;
                break;

            case KING:
                break;

            case EMPTY:
                break;
            }
        }
    }

    return score;
}

int HC_Eval::EvaluatePosition(Board& board)
{
    int score = 0;

    for (int x = 0; x < 8; x++)
    {
        for (int y = 0; y < 8; y++)
        {
            const Piece& p = board.board[x][y];

            if (p.type == EMPTY)
                continue;

            int value = 0;
            int tableX = (p.color == WHITE) ? x : 7 - x;

            switch (p.type)
            {
                case PAWN:
                    value = PawnTable[tableX][y];
                    break;

                case KNIGHT:
                    value = KnightTable[tableX][y];
                    break;

                case BISHOP:
                    value = BishopTable[tableX][y];
                    break;

                case ROOK:
                    value = RookTable[tableX][y];
                    break;

                case QUEEN:
                    value = QueenTable[tableX][y];
                    break;

                case KING:
                    value = KingTable[tableX][y];
                    break;

                default:
                    break;
            }

            // Mirror the table for Black
            if (p.color == WHITE)
                score += value;
            else
                score -= value;
        }
    }

    return score;
}

int HC_Eval::EvaluateMobility(Board& board)
{
    int whiteMoves = 0;
    int blackMoves = 0;

    for (int x = 0; x < 8; x++)
    {
        for (int y = 0; y < 8; y++)
        {
            const Piece& p = board.board[x][y];

            if (p.type == EMPTY)
                continue;

            vector<Move> moves = board.generateMoves(x, y);
            int moveCount = moves.size();

            if (p.color == WHITE)
                whiteMoves += moveCount;
            else
                blackMoves += moveCount;
        }
    }

    // 5 centipawns per legal move
    return (whiteMoves - blackMoves) * 5;
}

int HC_Eval::EvaluateKingSafety(Board& board)
{
    int score = 0;

    for (int x = 0; x < 8; x++)
    {
        for (int y = 0; y < 8; y++)
        {
            const Piece& p = board.board[x][y];

            if (p.type != KING)
                continue;

            int shield = 0;

            for (int dx = -1; dx <= 1; dx++)
            {
                for (int dy = -1; dy <= 1; dy++)
                {
                    if (dx == 0 && dy == 0)
                        continue;

                    int nx = x + dx;
                    int ny = y + dy;

                    if (nx < 0 || nx >= 8 || ny < 0 || ny >= 8)
                        continue;

                    if (board.board[nx][ny].color == p.color)
                        shield++;
                }
            }

            if (p.color == WHITE)
                score += shield * 15;
            else
                score -= shield * 15;
        }
    }

    return score;
}
int HC_Eval::Evaluate(Board& board)
{
    return
        EvaluateMaterial(board)
      + EvaluatePosition(board)
      + EvaluateMobility(board)
      + EvaluateKingSafety(board)
      + EvaluateBishopPair(board)
      + EvaluatePassedPawns(board)
      + EvaluateDoubledPawns(board)
      + EvaluateIsolatedPawns(board)
      + EvaluateRookActivity(board);
}
