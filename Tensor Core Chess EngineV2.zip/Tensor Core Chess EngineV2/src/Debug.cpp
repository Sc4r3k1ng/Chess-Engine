#include "Debug.h"

using namespace std;

Debug::Debug()
{
    //ctor
}

Debug::~Debug()
{
    //dtor
}
