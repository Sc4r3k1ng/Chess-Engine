#include "Min_Max.h"
#include <algorithm>
#include <atomic>
#include <limits>
#include <thread>
#include <vector>

using namespace std;

namespace
{
    const int INF = 100000000;
    const int MATE_SCORE = 1000000;
}

Min_Max::Min_Max() : threads(1)
{
}

Min_Max::~Min_Max() = default;

void Min_Max::SetThreads(int count)
{
    threads = max(1, count);
}

int Min_Max::GetThreads() const
{
    return threads;
}

int Min_Max::Search(Board& board, int depth, bool maximizingPlayer)
{
    return AlphaBeta(board, depth, -INF, INF, maximizingPlayer);
}

int Min_Max::AlphaBeta(Board& board, int depth, int alpha, int beta, bool maximizingPlayer)
{
    if (depth <= 0)
        return Quiescence(board, alpha, beta);

    const Color side = board.sideToMove;
    bool foundMove = false;

    if (maximizingPlayer)
    {
        int best = -INF;

        for (int x = 0; x < 8; ++x)
            for (int y = 0; y < 8; ++y)
            {
                if (board.board[x][y].type == EMPTY || board.board[x][y].color != side)
                    continue;

                vector<Move> moves = board.generateMoves(x, y);
                for (const Move& move : moves)
                {
                    foundMove = true;
                    Piece captured = board.makeMove(move);
                    board.sideToMove = (side == WHITE) ? BLACK : WHITE;

                    int score = AlphaBeta(board, depth - 1, alpha, beta, false);

                    board.sideToMove = side;
                    board.undoMove(move, captured);

                    best = max(best, score);
                    alpha = max(alpha, score);
                    if (alpha >= beta)
                        return best;
                }
            }

        if (!foundMove)
            return board.inCheck(side) ? -MATE_SCORE - depth : 0;

        return best;
    }

    int best = INF;

    for (int x = 0; x < 8; ++x)
        for (int y = 0; y < 8; ++y)
        {
            if (board.board[x][y].type == EMPTY || board.board[x][y].color != side)
                continue;

            vector<Move> moves = board.generateMoves(x, y);
            for (const Move& move : moves)
            {
                foundMove = true;
                Piece captured = board.makeMove(move);
                board.sideToMove = (side == WHITE) ? BLACK : WHITE;

                int score = AlphaBeta(board, depth - 1, alpha, beta, true);

                board.sideToMove = side;
                board.undoMove(move, captured);

                best = min(best, score);
                beta = min(beta, score);
                if (beta <= alpha)
                    return best;
            }
        }

    if (!foundMove)
        return board.inCheck(side) ? MATE_SCORE + depth : 0;

    return best;
}

int Min_Max::Quiescence(Board& board, int alpha, int beta)
{
    const bool maximizing = (board.sideToMove == WHITE);
    const int standPat = evaluator.Evaluate(board);

    if (maximizing)
    {
        if (standPat >= beta)
            return beta;
        alpha = max(alpha, standPat);
    }
    else
    {
        if (standPat <= alpha)
            return alpha;
        beta = min(beta, standPat);
    }

    const Color side = board.sideToMove;

    // Search only captures to reduce horizon effects.
    for (int x = 0; x < 8; ++x)
        for (int y = 0; y < 8; ++y)
        {
            if (board.board[x][y].type == EMPTY || board.board[x][y].color != side)
                continue;

            vector<Move> moves = board.generateMoves(x, y);
            for (const Move& move : moves)
            {
                if (board.board[move.toX][move.toY].type == EMPTY)
                    continue;

                Piece captured = board.makeMove(move);
                board.sideToMove = (side == WHITE) ? BLACK : WHITE;

                int score = Quiescence(board, alpha, beta);

                board.sideToMove = side;
                board.undoMove(move, captured);

                if (maximizing)
                {
                    if (score >= beta)
                        return beta;
                    alpha = max(alpha, score);
                }
                else
                {
                    if (score <= alpha)
                        return alpha;
                    beta = min(beta, score);
                }
            }
        }

    return maximizing ? alpha : beta;
}

int Min_Max::SearchRootMove(const Board& position, const Move& move, int depth, bool maximizingPlayer)
{
    Board searchBoard = position;
    const Color side = searchBoard.sideToMove;
    Piece captured = searchBoard.makeMove(move);
    searchBoard.sideToMove = (side == WHITE) ? BLACK : WHITE;

    int score = AlphaBeta(searchBoard, depth - 1, -INF, INF, !maximizingPlayer);

    // searchBoard is local, so no undo is required for correctness.
    (void)captured;
    return score;
}

Move Min_Max::FindBestMove(Board& board, int depth, bool maximizingPlayer)
{
    vector<Move> allMoves;
    const Color side = board.sideToMove;

    for (int x = 0; x < 8; ++x)
        for (int y = 0; y < 8; ++y)
        {
            if (board.board[x][y].type == EMPTY || board.board[x][y].color != side)
                continue;

            vector<Move> moves = board.generateMoves(x, y);
            allMoves.insert(allMoves.end(), moves.begin(), moves.end());
        }

    if (allMoves.empty())
        return Move{-1,-1,-1,-1};

    vector<int> scores(allMoves.size(), 0);
    const unsigned int workerCount = min(
        static_cast<unsigned int>(max(1, threads)),
        static_cast<unsigned int>(allMoves.size())
    );

    atomic<size_t> nextIndex(0);
    vector<thread> workers;
    workers.reserve(workerCount);

    auto worker = [&]()
    {
        while (true)
        {
            const size_t index = nextIndex.fetch_add(1, memory_order_relaxed);
            if (index >= allMoves.size())
                break;

            scores[index] = SearchRootMove(
                board,
                allMoves[index],
                depth,
                maximizingPlayer
            );
        }
    };

    for (unsigned int i = 0; i < workerCount; ++i)
        workers.emplace_back(worker);

    for (thread& t : workers)
        t.join();

    size_t bestIndex = 0;
    for (size_t i = 1; i < allMoves.size(); ++i)
    {
        if ((maximizingPlayer && scores[i] > scores[bestIndex]) ||
            (!maximizingPlayer && scores[i] < scores[bestIndex]))
            bestIndex = i;
    }

    return allMoves[bestIndex];
}
