#include "TWPAO_Eval.h"
#include <fstream>
TWPAO_Eval::TWPAO_Eval() {} TWPAO_Eval::~TWPAO_Eval() {} void TWPAO_Eval::RecordPosition(const std::vector<int>&,int r)
{
    samples.push_back(r);
}
void TWPAO_Eval::Train() {/*TODO*/} bool TWPAO_Eval::SaveWeights(const char* f)
{
    std::ofstream o(f);
    if(!o)return false;
    for(int s:samples)o<<s<<"\n";
    return true;
}
bool TWPAO_Eval::LoadWeights(const char*)
{
    return true;
}
