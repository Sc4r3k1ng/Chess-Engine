#include <iostream>
#include <sstream>
#include <vector>
#include "Board.h"

using namespace std;

Board::Board()
{
    for (int x = 0; x < 8; ++x)
        for (int y = 0; y < 8; ++y)
            board[x][y] = {EMPTY, NONE};
}

Board::~Board() = default;

bool Board::isInBounds(int x, int y)
{
    return x >= 0 && x < 8 && y >= 0 && y < 8;
}

vector<Move> Board::generateKingMoves(int x, int y)
{
    vector<Move> moves;
    static const int dirs[8][2] = {
        {1,0},{1,1},{0,1},{-1,1},
        {-1,0},{-1,-1},{0,-1},{1,-1}
    };

    for (const auto& d : dirs)
    {
        int nx = x + d[0], ny = y + d[1];
        if (isInBounds(nx, ny) &&
            (board[nx][ny].type == EMPTY ||
             board[nx][ny].color != board[x][y].color))
            moves.push_back({x,y,nx,ny});
    }
    return moves;
}

vector<Move> Board::generateQueenMoves(int x, int y)
{
    vector<Move> moves = generateRookMoves(x, y);
    vector<Move> bishop = generateBishopMoves(x, y);
    moves.insert(moves.end(), bishop.begin(), bishop.end());
    return moves;
}

vector<Move> Board::generateRookMoves(int x, int y)
{
    vector<Move> moves;
    static const int dirs[4][2] = {{1,0},{0,1},{-1,0},{0,-1}};

    for (const auto& d : dirs)
    {
        int nx = x + d[0], ny = y + d[1];
        while (isInBounds(nx, ny))
        {
            if (board[nx][ny].type != EMPTY)
            {
                if (board[nx][ny].color != board[x][y].color)
                    moves.push_back({x,y,nx,ny});
                break;
            }
            moves.push_back({x,y,nx,ny});
            nx += d[0];
            ny += d[1];
        }
    }
    return moves;
}

vector<Move> Board::generateBishopMoves(int x, int y)
{
    vector<Move> moves;
    static const int dirs[4][2] = {{1,1},{-1,1},{-1,-1},{1,-1}};

    for (const auto& d : dirs)
    {
        int nx = x + d[0], ny = y + d[1];
        while (isInBounds(nx, ny))
        {
            if (board[nx][ny].type != EMPTY)
            {
                if (board[nx][ny].color != board[x][y].color)
                    moves.push_back({x,y,nx,ny});
                break;
            }
            moves.push_back({x,y,nx,ny});
            nx += d[0];
            ny += d[1];
        }
    }
    return moves;
}

vector<Move> Board::generateKnightMoves(int x, int y)
{
    vector<Move> moves;
    static const int dirs[8][2] = {
        {2,1},{1,2},{-1,2},{-2,1},
        {-2,-1},{-1,-2},{1,-2},{2,-1}
    };

    for (const auto& d : dirs)
    {
        int nx = x + d[0], ny = y + d[1];
        if (isInBounds(nx, ny) &&
            (board[nx][ny].type == EMPTY ||
             board[nx][ny].color != board[x][y].color))
            moves.push_back({x,y,nx,ny});
    }
    return moves;
}

vector<Move> Board::generatePawnMoves(int x, int y)
{
    vector<Move> moves;
    Color side = board[x][y].color;
    int direction = (side == WHITE) ? 1 : -1;
    int startRank = (side == WHITE) ? 1 : 6;
    int nextX = x + direction;

    if (isInBounds(nextX, y) && board[nextX][y].type == EMPTY)
    {
        moves.push_back({x,y,nextX,y});

        int doubleX = x + 2 * direction;
        if (x == startRank && isInBounds(doubleX, y) &&
            board[doubleX][y].type == EMPTY)
            moves.push_back({x,y,doubleX,y});
    }

    if (isInBounds(nextX, y - 1) &&
        board[nextX][y - 1].type != EMPTY &&
        board[nextX][y - 1].color != side)
        moves.push_back({x,y,nextX,y - 1});

    if (isInBounds(nextX, y + 1) &&
        board[nextX][y + 1].type != EMPTY &&
        board[nextX][y + 1].color != side)
        moves.push_back({x,y,nextX,y + 1});

    return moves;
}

void Board::Show_Board()
{
    for (int x = 7; x >= 0; --x)
    {
        for (int y = 0; y < 8; ++y)
        {
            char c = '.';
            const Piece& p = board[x][y];
            if (p.type != EMPTY)
            {
                static const char symbols[] = "KQRBNP";
                c = symbols[p.type - KING];
                if (p.color == BLACK)
                    c = static_cast<char>(tolower(c));
            }
            cout << c << ' ';
        }
        cout << '\n';
    }
}

void Board::Load_FEN(const string& FEN)
{
    for (int x = 0; x < 8; ++x)
        for (int y = 0; y < 8; ++y)
            board[x][y] = {EMPTY, NONE};

    stringstream ss(FEN);
    string placement, activeColor;
    ss >> placement >> activeColor;

    int rank = 7;
    int file = 0;

    for (char c : placement)
    {
        if (c == '/')
        {
            --rank;
            file = 0;
            continue;
        }

        if (c >= '1' && c <= '8')
        {
            file += c - '0';
            continue;
        }

        if (rank < 0 || file >= 8)
            continue;

        Color color = (isupper(static_cast<unsigned char>(c))) ? WHITE : BLACK;
        char lower = static_cast<char>(tolower(static_cast<unsigned char>(c)));
        PieceType type = EMPTY;

        switch (lower)
        {
            case 'k': type = KING;   break;
            case 'q': type = QUEEN;  break;
            case 'r': type = ROOK;   break;
            case 'b': type = BISHOP; break;
            case 'n': type = KNIGHT; break;
            case 'p': type = PAWN;   break;
            default:  type = EMPTY;  break;
        }

        if (type != EMPTY)
        {
            board[rank][file] = {type, color};
            ++file;
        }
    }

    sideToMove = (activeColor == "b") ? BLACK : WHITE;
}

pair<int,int> Board::findKing(Color color)
{
    for (int x = 0; x < 8; ++x)
        for (int y = 0; y < 8; ++y)
            if (board[x][y].type == KING && board[x][y].color == color)
                return {x,y};

    return {-1,-1};
}

Piece Board::makeMove(const Move& move)
{
    Piece captured = board[move.toX][move.toY];
    board[move.toX][move.toY] = board[move.fromX][move.fromY];
    board[move.fromX][move.fromY] = {EMPTY, NONE};
    return captured;
}

void Board::undoMove(const Move& move, Piece captured)
{
    board[move.fromX][move.fromY] = board[move.toX][move.toY];
    board[move.toX][move.toY] = captured;
}

bool Board::isSquareAttacked(int x, int y, Color attacker)
{
    int pawnDir = (attacker == WHITE) ? 1 : -1;
    int px = x - pawnDir;

    if (isInBounds(px, y - 1) && board[px][y - 1].type == PAWN && board[px][y - 1].color == attacker)
        return true;
    if (isInBounds(px, y + 1) && board[px][y + 1].type == PAWN && board[px][y + 1].color == attacker)
        return true;

    static const int knight[8][2] = {
        {2,1},{2,-1},{-2,1},{-2,-1},
        {1,2},{1,-2},{-1,2},{-1,-2}
    };
    for (const auto& d : knight)
    {
        int nx = x + d[0], ny = y + d[1];
        if (isInBounds(nx, ny) && board[nx][ny].type == KNIGHT && board[nx][ny].color == attacker)
            return true;
    }

    static const int rookDir[4][2] = {{1,0},{-1,0},{0,1},{0,-1}};
    for (const auto& d : rookDir)
    {
        int nx = x + d[0], ny = y + d[1];
        while (isInBounds(nx, ny))
        {
            if (board[nx][ny].type != EMPTY)
            {
                if (board[nx][ny].color == attacker &&
                    (board[nx][ny].type == ROOK || board[nx][ny].type == QUEEN))
                    return true;
                break;
            }
            nx += d[0]; ny += d[1];
        }
    }

    static const int bishopDir[4][2] = {{1,1},{1,-1},{-1,1},{-1,-1}};
    for (const auto& d : bishopDir)
    {
        int nx = x + d[0], ny = y + d[1];
        while (isInBounds(nx, ny))
        {
            if (board[nx][ny].type != EMPTY)
            {
                if (board[nx][ny].color == attacker &&
                    (board[nx][ny].type == BISHOP || board[nx][ny].type == QUEEN))
                    return true;
                break;
            }
            nx += d[0]; ny += d[1];
        }
    }

    for (int dx = -1; dx <= 1; ++dx)
        for (int dy = -1; dy <= 1; ++dy)
        {
            if (dx == 0 && dy == 0) continue;
            int nx = x + dx, ny = y + dy;
            if (isInBounds(nx, ny) && board[nx][ny].type == KING && board[nx][ny].color == attacker)
                return true;
        }

    return false;
}

bool Board::inCheck(Color side)
{
    pair<int,int> king = findKing(side);
    if (king.first < 0)
        return true;

    Color enemy = (side == WHITE) ? BLACK : WHITE;
    return isSquareAttacked(king.first, king.second, enemy);
}

vector<Move> Board::generateMoves(int x, int y)
{
    vector<Move> pseudo;
    vector<Move> legal;

    if (!isInBounds(x, y) || board[x][y].type == EMPTY)
        return legal;

    switch (board[x][y].type)
    {
        case KING:   pseudo = generateKingMoves(x,y); break;
        case QUEEN:  pseudo = generateQueenMoves(x,y); break;
        case ROOK:   pseudo = generateRookMoves(x,y); break;
        case BISHOP: pseudo = generateBishopMoves(x,y); break;
        case KNIGHT: pseudo = generateKnightMoves(x,y); break;
        case PAWN:   pseudo = generatePawnMoves(x,y); break;
        default: break;
    }

    Color side = board[x][y].color;

    for (const Move& move : pseudo)
    {
        // Kings are never captured in chess; checkmate ends the game.
        if (board[move.toX][move.toY].type == KING)
            continue;

        Piece captured = makeMove(move);
        if (!inCheck(side))
            legal.push_back(move);
        undoMove(move, captured);
    }

    return legal;
}

bool Board::hasLegalMoves(Color side)
{
    for (int x = 0; x < 8; ++x)
        for (int y = 0; y < 8; ++y)
            if (board[x][y].type != EMPTY && board[x][y].color == side && !generateMoves(x,y).empty())
                return true;
    return false;
}
